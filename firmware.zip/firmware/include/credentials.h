// Wi‑Fi credentials for the ESP32

#define WIFI_SSID "UCSD-GUEST"
//#define WIFI_SSID "RESNET-GUEST-DEVICE"
//#define WIFI_PASS "ResnetConnect"